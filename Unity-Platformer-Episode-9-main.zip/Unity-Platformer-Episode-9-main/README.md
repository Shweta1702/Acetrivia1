# Unity-Platformer-Episode-9
2D platformer for complete beginners in Unity. Episode 9. Adding 4 types of traps: spikes, firetraps, arrow traps and crush blocks. https://youtu.be/5EesvCG9_FA
